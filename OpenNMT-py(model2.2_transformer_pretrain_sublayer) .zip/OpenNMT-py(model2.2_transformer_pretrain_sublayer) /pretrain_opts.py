#path
encoder_model_path = "../pytorch_doc_models/train_25w_adam_0.000005_transformer_load_pretrain_cache25_batch800_no_repeat_2step_only_acc_52.47_ppl_7.61_e4.pt"
train_src_path = "./pretrain_data/src-train.txt"
train_tgt_path = "./pretrain_data/tgt-train.txt"
dev_src_path = "./pretrain_data/src-dev.txt"
dev_tgt_path = "./pretrain_data/tgt-dev.txt"
save_model = "pretrain_tagger"

#model
hidden_size = 512
rnn_type = "LSTM"
seed = 1234
param_init = 0.1
param_init_glorot = False

#train
epochs = 8
max_doc_size = 80
batch_size = 128
valid_batch_size = 5
accum_count = 2
batch_type = "sentences"
gpuid = []

#optim
optim = "adam"
learning_rate = 0.001
max_grad_norm = 5
learning_rate_decay = 0.5
start_decay_at = 3
adam_beta1 = 0.9
adam_beta2 =0.999
adagrad_accumulator_init = 0
decay_method = ""
warmup_steps = 4000
label_smoothing = 0.1
dropout = 0.1

#others
truncated_decoder = 0
max_generator_batches = 32
normalization = "tokens"
report_every = 1

#控制是否单独训练判断存储的模型
train_save_model = True

#判断是否接着之前的参数进行训练
pretrain_model_param = False