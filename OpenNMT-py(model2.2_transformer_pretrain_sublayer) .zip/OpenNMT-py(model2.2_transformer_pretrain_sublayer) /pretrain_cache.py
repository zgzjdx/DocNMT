from __future__ import division

import torch
import torch.nn as nn
import torchtextdoc
import random
from collections import Counter, defaultdict, OrderedDict
import onmt
import onmt.io
import onmt.Models
import onmt.ModelConstructor
from onmt.Utils import use_gpu
from torch.nn.init import xavier_uniform

from pretrain_models import Tagger,LogisticLinear\
    ,NMTLossCompute,NMTSaveLossCompute
import pretrain_utils
import pretrain_opts

#torch.cuda.set_device(4)

#定义要保存的成分
to_save = ["B-TOP","I-TOP"]

def load_checkpoint(path):
    #加载模型参数
    print('Loading checkpoint from %s' % path)
    checkpoint = torch.load(path,
                            map_location=lambda storage, loc: storage)
    return checkpoint

def load_encoder(checkpoint):
    #提取模型中encoder的参数
    model_opt = checkpoint["opt"]
    encoder_parameters = {}
    for key in checkpoint["model"]:
        if "encoder" in key:
            new_key = key.replace("encoder.","")
            encoder_parameters[new_key] = checkpoint["model"][key]
    #加载原本模型的encoder的参数
    src_dict = fields["src"].vocab
    feature_dicts = onmt.io.collect_feature_vocabs(fields, 'src')
    src_embeddings = onmt.ModelConstructor.make_embeddings(model_opt, src_dict,
                                     feature_dicts)
    encoder = onmt.ModelConstructor.make_encoder(model_opt, src_embeddings)
    print("Setting encoder parameters......")
    encoder.load_state_dict(encoder_parameters, strict=True)

    return encoder

def rebuild_tgt_field(fields,dataset):
    counter = Counter()
    # 只需要用预训练模型的src field tgt的field需要单独构建
    fields["tgt"] = torchtextdoc.data.Field(
        init_token=onmt.io.BOS_WORD, eos_token=None, doc_token="<DOCUMENT>",
        pad_token=onmt.io.PAD_WORD)
    for document in dataset.examples:
        for ex in document.sentences:
            val = [item for item in ex.tgt]
            counter.update(val)

    def _build_field_vocab(field, counter, **kwargs):
        specials = list(OrderedDict.fromkeys(
            tok for tok in [field.unk_token, field.pad_token, field.init_token,
                            field.eos_token]
            if tok is not None))
        field.vocab = field.vocab_cls(counter, specials=specials, **kwargs)

    _build_field_vocab(fields["tgt"], counter,
                       max_size=50000,
                       min_freq=1)
    print(" * tgt vocab size: %d." % len(fields["tgt"].vocab))

    return fields

def make_loss_compute(model, tgt_vocab, opt, save_list,train=True,train_save_model=False):
    """
    This returns user-defined LossCompute object, which is used to
    compute loss in train/validate process. You can implement your
    own *LossCompute class, by subclassing LossComputeBase.
    """
    if train_save_model:
        compute = NMTSaveLossCompute(
            model.generator, tgt_vocab,
            model.logistic_linear,save_list,
            label_smoothing=opt.label_smoothing if train else 0.5)
    else:
        compute = NMTLossCompute(
            model.generator, tgt_vocab,
            model.logistic_linear,save_list,
            label_smoothing=opt.label_smoothing if train else 0.5)

    if use_gpu(opt):
        compute.cuda()

    return compute

def report_func(epoch, batch, num_batches,
                progress_step,
                start_time, lr, report_stats):
    #todo 篇章iterator会影响report 因为无法知道确切的batch数量 但是这个report对实际训练没影响 这里不做修改
    if batch % pretrain_opts.report_every == -1 % pretrain_opts.report_every:
        report_stats.output(epoch, batch + 1, num_batches, start_time)
        report_stats = pretrain_utils.Statistics()

    return report_stats

def train_model(model, fields, optim,
                train_iter,valid_iter,
                data_type, pretrain_opts):
    save_list = []
    for tag in to_save:
        save_list.append(fields["tgt"].vocab.stoi[tag])
    train_loss = make_loss_compute(model, fields["tgt"].vocab, pretrain_opts,save_list)
    valid_loss = make_loss_compute(model, fields["tgt"].vocab, pretrain_opts,save_list,
                                   train=False)

    trunc_size = pretrain_opts.truncated_decoder  # Badly named...
    shard_size = pretrain_opts.max_generator_batches
    norm_method = pretrain_opts.normalization
    grad_accum_count = pretrain_opts.accum_count

    trainer = pretrain_utils.Trainer(model, train_loss, valid_loss, optim,
                           trunc_size, shard_size, data_type,
                           norm_method, grad_accum_count)

    print('\nStart training...')

    print(' * batch size: %d' % pretrain_opts.batch_size)

    for epoch in range(pretrain_opts.epochs + 1):

        # 1. Train for one epoch on the training set.

        train_stats = trainer.train(train_iter, epoch, report_func)
        print('Train perplexity: %g' % train_stats.ppl())
        print('Train accuracy: %g' % train_stats.accuracy())
        print('Train save_accuracy: %g' % train_stats.save_accuracy())

        # 2. Validate on the validation set.

        valid_stats = trainer.validate(valid_iter)
        print('Validation perplexity: %g' % valid_stats.ppl())
        print('Validation accuracy: %g' % valid_stats.accuracy())
        print('Validation save_accuracy: %g' % valid_stats.save_accuracy())
        print('Validation pred_precision: %g' % valid_stats.pred_precision())
        print('Validation pred_recall: %g' % valid_stats.pred_recall())
        print('Validation save_precision: %g' % valid_stats.save_precision())
        print('Validation save_recall: %g' % valid_stats.save_recall())
        # 3. Update the learning rate
        trainer.epoch_step(valid_stats.ppl(), epoch)

        # 4. Drop a checkpoint if needed.
        trainer.drop_checkpoint(pretrain_opts, epoch, fields, valid_stats)

def train_save_model(model, fields, optim,
                train_iter,valid_iter,
                data_type, pretrain_opts):
    save_list = []
    for tag in to_save:
        save_list.append(fields["tgt"].vocab.stoi[tag])
    train_loss = make_loss_compute(model, fields["tgt"].vocab, pretrain_opts,save_list,train_save_model=True)
    valid_loss = make_loss_compute(model, fields["tgt"].vocab, pretrain_opts,save_list,
                                   train=False,train_save_model=True)

    trunc_size = pretrain_opts.truncated_decoder  # Badly named...
    shard_size = pretrain_opts.max_generator_batches
    norm_method = pretrain_opts.normalization
    grad_accum_count = pretrain_opts.accum_count

    trainer = pretrain_utils.Trainer(model, train_loss, valid_loss, optim,
                           trunc_size, shard_size, data_type,
                           norm_method, grad_accum_count)

    print('\nStart training...')

    print(' * batch size: %d' % pretrain_opts.batch_size)

    for epoch in range(pretrain_opts.epochs + 1):
        print('')

        # 1. Train for one epoch on the training set.

        train_stats = trainer.train(train_iter, epoch, report_func)
        print('Train perplexity: %g' % train_stats.ppl())
        print('Train accuracy: %g' % train_stats.accuracy())
        print('Train save_accuracy: %g' % train_stats.save_accuracy())

        # 2. Validate on the validation set.

        valid_stats = trainer.validate(valid_iter)
        print('Validation perplexity: %g' % valid_stats.ppl())
        print('Validation accuracy: %g' % valid_stats.accuracy())
        print('Validation save_accuracy: %g' % valid_stats.save_accuracy())
        # 3. Update the learning rate
        trainer.epoch_step(valid_stats.ppl(), epoch)

        # 4. Drop a checkpoint if needed.
        trainer.drop_checkpoint(pretrain_opts, epoch, fields, valid_stats)
if __name__ == '__main__':
    #加载随机数种子
    if pretrain_opts.seed > 0:
        random.seed(pretrain_opts.seed)
        torch.manual_seed(pretrain_opts.seed)

    checkpoint = load_checkpoint(pretrain_opts.encoder_model_path)
    fields = onmt.io.load_fields_from_vocab(
        checkpoint['vocab'], "text")

    # 构造数据集
    print('Building training datasets......')
    train_data = onmt.io.build_dataset("sentences",
                                 fields,
                                 "text",
                                 pretrain_opts.train_src_path,
                                 pretrain_opts.train_tgt_path,
                                 src_dir="",
                                 sample_rate='16000',
                                 window_size=.02,
                                 window_stride=.01,
                                 window='hamming',
                                 use_filter_pred=False)
    fields = rebuild_tgt_field(fields, train_data)
    train_data.fields = fields

    print('Building validation datasets......')
    valid_data = onmt.io.build_dataset("sentences",
                                       fields,
                                       "text",
                                       pretrain_opts.dev_src_path,
                                       pretrain_opts.dev_tgt_path,
                                       src_dir="",
                                       sample_rate='16000',
                                       window_size=.02,
                                       window_stride=.01,
                                       window='hamming',
                                       use_filter_pred=False)

    train_iter = pretrain_utils.make_dataset_iter(train_data, pretrain_opts, is_train=True)
    valid_iter = pretrain_utils.make_dataset_iter(valid_data, pretrain_opts, is_train=False)

    # 加载encoder
    encoder = load_encoder(checkpoint)
    #定义一个logistic linear作为单独的节点
    logistic_linear = LogisticLinear()
    # 构造模型
    model = Tagger(encoder)
    generator = nn.Sequential(
        nn.Linear(pretrain_opts.hidden_size, len(fields["tgt"].vocab)),
        nn.LogSoftmax(dim=-1))
    model.generator = generator
    model.logistic_linear = logistic_linear

    if use_gpu(pretrain_opts):
        model.cuda()
    else:
        model.cpu()
    # 初始化模型新的参数
    if pretrain_opts.pretrain_model_param:
        rnn_param = {}
        logistic_linear_param = {}
        for k in checkpoint["model"]:
            if "dynamic_cache.cache_embedding_rnn" in k:
                new_key = k.replace("dynamic_cache.cache_embedding_rnn.","")
                rnn_param[new_key] = checkpoint["model"][k]
            elif "dynamic_cache.linear" in k:
                new_key = k.replace("dynamic_cache.linear.", "linear.")
                logistic_linear_param[new_key] = checkpoint["model"][k]
            else:
                pass
        model.cache_embedding_rnn.load_state_dict(rnn_param,strict=True)
        model.logistic_linear.load_state_dict(logistic_linear_param, strict=True)
    else:
        if pretrain_opts.param_init != 0.0:
            print('Intializing rnn parameters.')
            for p in model.cache_embedding_rnn.parameters():
                p.data.uniform_(-pretrain_opts.param_init, pretrain_opts.param_init)
            print('Intializing linear parameters.')
            for p in model.logistic_linear.parameters():
                p.data.uniform_(-pretrain_opts.param_init, pretrain_opts.param_init)
        if pretrain_opts.param_init_glorot:
            for p in model.dynamic_cache.parameters():
                if p.dim() > 1:
                    xavier_uniform(p)
            for p in model.linear.parameters():
                if p.dim() > 1:
                    xavier_uniform(p)
    # 构造优化器
    print('Making optimizer for cache training.')
    optim = onmt.Optim(
        pretrain_opts.optim, pretrain_opts.learning_rate, pretrain_opts.max_grad_norm,
        lr_decay=pretrain_opts.learning_rate_decay,
        start_decay_at=pretrain_opts.start_decay_at,
        beta1=pretrain_opts.adam_beta1,
        beta2=pretrain_opts.adam_beta2,
        adagrad_accum=pretrain_opts.adagrad_accumulator_init,
        decay_method=pretrain_opts.decay_method,
        warmup_steps=pretrain_opts.warmup_steps,
        model_size=pretrain_opts.hidden_size)
    to_optim = []
    for k,p in model.named_parameters():
        if "encoder" in k:
            pass
        else:
            to_optim.append((k,p))
    optim.set_parameters(to_optim)


    #训练模型
    train_model(model,fields,optim,
                train_iter,valid_iter,
                "text",pretrain_opts)
