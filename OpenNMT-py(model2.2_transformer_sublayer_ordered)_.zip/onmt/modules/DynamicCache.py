import torch
import torch.nn as nn
from torch.autograd import Variable
import onmt
from onmt.Utils import aeq, sequence_mask


class DynamicCache(nn.Module):
    #初始化
    def __init__(self, cache_dim,cache_size
                 #网络参数
                 ,rnn_type,input_size,num_layers,dropout):
        super(DynamicCache, self).__init__()
        # cache_dim 暂定 cache的维度
        # cache_size cache的大小
        self.cache_dim = int(cache_dim)
        self.cache_size = int(cache_size)
        #定义一个网络,输入是encoder context,输出是将要存入cache中的跨句信息
        #输出的维度是cache_dim
        self.cache_embedding_rnn = getattr(nn, rnn_type)(
                        input_size=input_size,
                        hidden_size=cache_dim,
                        num_layers=num_layers,
                        dropout=dropout)
        #linear和sigmoid函数 用于给当前的状态表示进行打分 logistic回归的概率
        self.sigmoid = nn.Sigmoid()
        self.linear = nn.Linear(cache_dim,1,bias=False)
        #定义一个网络初始的hidden = None
        self.hidden = None
        #key-value cache key存储document状态 value存储encoder的原始状态 score存储sigomoid函数得到的概率打分
        self.key = []
        self.value = []
        self.score = []
        #将存入cache的src存储进去 打印attn的时候用
        self.word_cache = []
        #cache_length
        # todo 模型2.1当中 两个global attention 需要额外定义document_memory_lengths
        self.document_memory_lengths = None

        self.oldest_index = 0

    def forward(self,src,memory_bank,document_end,reorder_index):
        #memory bank 是当前步骤的encoder出来的结果 `[src_len x batch x dim]`
        #document end 判断篇章是否结束,结束则清除cache
        #reorder_index 用于判断该步骤的memory bank对应的cache的索引
        #self.hidden 用上一句的hidden初始化下一句的hidden 直到篇章结束后重置 暂未使用
        if document_end:
            self.word_cache = []
            self.key = []
            self.value = []
            self.score = []
            self.hidden = None
            self.document_memory_lengths = None
            return self.key,self.value
        else:
            #此时篇章刚翻译第一句,cache是空的,根据memory bank向cache中写入
            if self.key == []:
                # src_len, batch_size ,memory_hidden_size = memory_bank.size()
                #转换memory bank的维度 根据batch的索引 也就是篇章的索引 构建cache
#                for word_context in memory_bank.split(1):
#                    word_context = word_context.squeeze(0)
                doc_context , hidden = self.cache_embedding_rnn(memory_bank,self.hidden)
                #cache writing步骤
                #i是time step的索引 reorder_index[j]是篇章的索引
                for i in range(len(doc_context)):
                    word_context = doc_context[i]
                    word_state = memory_bank[i]
                    word = src[i]
                    for j in range(len(reorder_index)):
                        # origin_index表示的是 在memory bank当中,原本的第N个语篇在第几个位置
                        origin_index = reorder_index.index(j)
                        # document_index表示的是 当前遍历到的状态是第几个语篇的
                        document_index = reorder_index[j]
                        if i == 0:
                            self.word_cache.append(word[origin_index])
                            self.key.append(word_context[origin_index].unsqueeze(0))
                            self.value.append(word_state[origin_index].unsqueeze(0))
                            self.score.append([float(self.sigmoid(self.linear(word_context[origin_index])))])
                        else:
                            if int(word[j].data) == 1:  # padding 跳过
                                continue
                            elif int(word[j].data) == 0:  # unk 不存储
                                continue
                            if len(self.key[document_index]) < self.cache_size:
                                self.word_cache[document_index] = \
                                    torch.cat((self.word_cache[document_index], word[j]))
                                self.key[document_index] = \
                                    torch.cat((self.key[document_index],word_context[j].unsqueeze(0)))
                                self.value[document_index] = \
                                    torch.cat((self.value[document_index], word_state[j].unsqueeze(0)))
                                self.score[document_index]\
                                    .append(float(self.sigmoid(self.linear(word_context[j]))))
                            #todo 根据score的值替换分数最小的状态
                            else:
                                if self.oldest_index >= self.cache_size:
                                    self.oldest_index = 0
                                self.word_cache[document_index][self.oldest_index].data = word[j].data
                                self.key[document_index][self.oldest_index].data = word_context[j].data
                                self.value[document_index][self.oldest_index].data = word_state[j].data
                                self.score[document_index][self.oldest_index] = float(self.sigmoid(self.linear(word_context[j])))
                                self.oldest_index += 1

                #检查cache当中的长度 如果没有的话进行padding
                length = []
                for cache_index in range(len(reorder_index)):
                    # 定义cache_length
                    length.append(len(self.value[cache_index]))
                    #定义完cache长度之后进行padding
                    if len(self.value[cache_index]) < self.cache_size:
                        # 由于句子长短的问题没有将cache填满 padding
                        diff = self.cache_size - len(self.value[cache_index])
                        if torch.cuda.is_available():  # 判断是否在gpu上跑
                            word_pad = Variable(torch.cuda.LongTensor(diff * [1]).transpose(-1,0),
                                                                       requires_grad=False)
                            pad = Variable(torch.cuda.FloatTensor(diff,
                                                                  self.cache_dim).zero_(), requires_grad=True)
                        else:
                            word_pad = Variable(torch.LongTensor(diff * [1]).transpose(-1,0),
                                                                 requires_grad=False)
                            pad = Variable(torch.FloatTensor(diff,
                                                             self.cache_dim).zero_(), requires_grad=True)
                        self.word_cache[cache_index] = torch.cat((self.word_cache[cache_index], word_pad), 0)
                        self.key[cache_index] = torch.cat((self.key[cache_index], pad), 0)
                        self.value[cache_index] = torch.cat((self.value[cache_index], pad), 0)
                        for zero in range(diff):
                            self.score[cache_index].append(float(0))
                if torch.cuda.is_available():
                    self.document_memory_lengths = torch.cuda.LongTensor(length)
                else:
                    self.document_memory_lengths = torch.LongTensor(length)
            #此时开始翻译第二句,cache不为空
            else:
                # src_len, batch_size, memory_hidden_size = memory_bank.size()
                # 转换memory bank的维度 根据batch的索引 也就是篇章的索引 构建cache
                #                for word_context in memory_bank.split(1):
                #                    word_context = word_context.squeeze(0)
                doc_context, hidden = self.cache_embedding_rnn(memory_bank, self.hidden)
                # cache writing步骤
                # i是time step的索引 j是篇章的索引
                for i in range(len(doc_context)):
                    word_context = doc_context[i]
                    word_state = memory_bank[i]
                    word = src[i]
                    for j in range(len(reorder_index)):
                        document_index = reorder_index[j]
                        if int(word[document_index].data) == 1:#padding 跳过
                            continue
                        elif int(word[j].data) == 0:#unk 不存储
                            continue
                        if len(self.key[document_index]) < self.cache_size:
                            self.word_cache[document_index] = \
                                torch.cat((self.word_cache[document_index], word[j]))
                            self.key[document_index] = \
                                torch.cat((self.key[document_index], word_context[j].unsqueeze(0)))
                            self.value[document_index] = \
                                torch.cat((self.value[document_index], word_state[j].unsqueeze(0)))
                            self.score[document_index] \
                                .append(float(self.sigmoid(self.linear(word_context[j]))))
                        # todo 根据score的值替换分数最小的状态
                        else:
                            if self.oldest_index >= self.cache_size:
                                self.oldest_index = 0
                            self.word_cache[document_index][self.oldest_index].data = word[j].data
                            self.key[document_index][self.oldest_index].data = word_context[j].data
                            self.value[document_index][self.oldest_index].data = word_state[j].data
                            self.score[document_index][self.oldest_index] = float(
                                self.sigmoid(self.linear(word_context[j])))
                            self.oldest_index += 1
                # 检查cache当中的长度 如果没有的话进行padding
                length = []
                for cache_index in range(len(reorder_index)):
                    # 定义cache_length
                    length.append(len(self.value[cache_index]))
                    # 定义完cache长度之后进行padding
                    if len(self.value[cache_index]) < self.cache_size:
                        # 由于句子长短的问题没有将cache填满 padding
                        diff = self.cache_size - len(self.value[cache_index])
                        if torch.cuda.is_available():  # 判断是否在gpu上跑
                            word_pad = Variable(torch.cuda.LongTensor(diff * [1]).transpose(-1, 0),
                                                requires_grad=False)
                            pad = Variable(torch.cuda.FloatTensor(diff,
                                                                  self.cache_dim).zero_(),
                                           requires_grad=True)
                        else:
                            word_pad = Variable(torch.LongTensor(diff * [1]).transpose(-1, 0),
                                                requires_grad=False)
                            pad = Variable(torch.FloatTensor(diff,
                                                             self.cache_dim).zero_(),
                                           requires_grad=True)
                        self.word_cache[cache_index] = torch.cat(
                            (self.word_cache[cache_index], word_pad), 0)
                        self.key[cache_index] = torch.cat((self.key[cache_index], pad), 0)
                        self.value[cache_index] = torch.cat((self.value[cache_index], pad), 0)
                        for zero in range(diff):
                            self.score[cache_index].append(float(0))
                if torch.cuda.is_available():
                    self.document_memory_lengths = torch.cuda.LongTensor(length)
                else:
                    self.document_memory_lengths = torch.LongTensor(length)