import torch.nn as nn
import onmt
from onmt.modules.Transformer import PositionwiseFeedForward

class DocumentAttentionLayer(nn.Module):
    """
    用multiheaded attention 做document attention.

    Args:
            size(int): the dimension of keys/values/queries in
                       MultiHeadedAttention, also the input size of
                       the first-layer of the PositionwiseFeedForward.
            droput(float): dropout probability(0-1.0).
            head_count(int): the number of head for MultiHeadedAttention.
            hidden_size(int): the second-layer of the PositionwiseFeedForward.
    """

    def __init__(self, size, dropout=0, #todo最后再做drop out 这里暂时定义为0
                 head_count=8, hidden_size=512):
        super(DocumentAttentionLayer, self).__init__()

        self.self_attn = onmt.modules.MultiHeadedAttention(
            head_count, size, dropout=dropout)
        self.feed_forward = PositionwiseFeedForward(size,
                                                    hidden_size,
                                                    dropout)
        self.layer_norm = onmt.modules.LayerNorm(size)

    def forward(self, key,value,query,mask):
        #multiheaded attention
        context, attn = self.self_attn(key, value, query,
                                    mask=mask)#key, value, query
        #fnn
        dt = self.feed_forward(context)
        #norm
        out = self.layer_norm(dt)

        return out,attn


#对document context 进行运算的结点
class DocumentGate(nn.Module):
    #初始化
    def __init__(self, dim, attn_type = "general"):
        super(DocumentGate, self).__init__()
        # 这一层用于对cache当中的内容进行attention
        self.document_attention = DocumentAttentionLayer(dim)
        #上下文的权重
        self.document_weight = nn.Linear(dim,1,bias=False)
        #当前句子的权重
        self.sequence_weight = nn.Linear(dim,1,bias=False)
        #sigmoid gate
        self.sigmoid_gate = nn.Sigmoid()

    def forward(self,rnn_output,decoder_output,
                document_context,document_state_context,
                mask,document_memory_lengths= None):

        # context_output, copy_attn = self.copy_attn(document_state_context.transpose(0, 1),
        #                               document_context.transpose(0, 1),
        #                               rnn_output.unsqueeze(1))
        # if document_memory_lengths.max() < len(document_context):#防止mask不匹配 在multihead attention当中 由于mask是包括了所有句子长度 因此不用做这个步骤
        #     document_context = document_context[:document_memory_lengths.max()]
        #     mask = mask[:document_memory_lengths.max()]
        document_output, document_attn = self.document_attention(
                                                            document_state_context.transpose(0, 1),
                                                            document_context.transpose(0, 1),
                                                            rnn_output.unsqueeze(1),
                                                            mask=mask)
        document_output = document_output.squeeze(1)
        document_attn = document_attn.squeeze(1)
        # 得到document context权重
        weight_d = self.document_weight(document_output)
        # 得到当前sequnence权重
        weight_s = self.sequence_weight(decoder_output)
        # 得到gate权重
        weight_gate = self.sigmoid_gate(weight_d+weight_s)
        #得到final_output
        final_output = weight_gate * decoder_output + (1-weight_gate) * document_output

        return final_output,document_attn,weight_gate

