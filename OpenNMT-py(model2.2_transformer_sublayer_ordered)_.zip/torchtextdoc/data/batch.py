import torch


class Batch(object):
    """Defines a batch of examples along with its Fields.

    Attributes:
        batch_size: Number of examples in the batch.
        dataset: A reference to the dataset object the examples come from
            (which itself contains the dataset's Field objects).
        train: Whether the batch is from a training set.

    Also stores the Variable for each column in the batch as an attribute.
    """

    def __init__(self, data=None,reorder_index = None,dataset=None, device=None, train=True):
        """Create a Batch from a list of examples."""
        #reorder index 由于rnn的运算padding操作需要强制排序，因此在batch中要附带原来的index信息
        if data is not None:
            self.batch_size = len(data)
            setattr(self, 'reorder_index', reorder_index)
            self.dataset = dataset
            self.train = train
            self.fields = list(dataset.fields.keys())# copy field names
            #用排序之前的第一个example来判断
            if hasattr(data[reorder_index.index(0)], 'document_index') \
                    and hasattr(data[reorder_index.index(0)], 'sentence_index'):
                #判断是否在解码 或者验证集
                self.fields.append('document_index')
                self.fields.append('sentence_index')
                self.fields.append('document_end')
                setattr(self, 'document_index',data[reorder_index.index(0)].document_index)
                setattr(self, 'sentence_index', data[reorder_index.index(0)].sentence_index)
                setattr(self, 'document_end', data[reorder_index.index(0)].document_end)
            # todo 加入document index 以及 sentence index
            # todo 为了不对之前的代码影响太大,在此处加入判断document index和sentence index
            # todo 只支持batch=1
            for (name, field) in dataset.fields.items():
                if field is not None:
                    batch = [getattr(x, name) for x in data]
                    setattr(self, name, field.process(batch, device=device, train=train))


    @classmethod
    def fromvars(cls, dataset, batch_size, train=True, **kwargs):
        """Create a Batch directly from a number of Variables."""
        batch = cls()
        batch.batch_size = batch_size
        batch.dataset = dataset
        batch.train = train
        batch.fields = dataset.fields.keys()
        for k, v in kwargs.items():
            setattr(batch, k, v)
        return batch

    def __repr__(self):
        return str(self)

    def __str__(self):
        if not self.__dict__:
            return 'Empty {} instance'.format(torch.typename(self))

        var_strs = '\n'.join(['\t[.' + name + ']' + ":" + _short_str(getattr(self, name))
                              for name in self.fields if hasattr(self, name)])

        data_str = (' from {}'.format(self.dataset.name.upper())
                    if hasattr(self.dataset, 'name') and
                    isinstance(self.dataset.name, str) else '')

        strt = '[{} of size {}{}]\n{}'.format(torch.typename(self),
                                              self.batch_size, data_str, var_strs)
        return '\n' + strt

    def __len__(self):
        return self.batch_size


def _short_str(tensor):
    # unwrap variable to tensor
    if not torch.is_tensor(tensor):
        # (1) unpack variable
        if hasattr(tensor, 'data'):
            tensor = getattr(tensor, 'data')
        # (2) handle include_lengths
        elif isinstance(tensor, tuple):
            return str(tuple(_short_str(t) for t in tensor))
        # (3) fallback to default str
        else:
            return str(tensor)

    # copied from torch _tensor_str
    size_str = 'x'.join(str(size) for size in tensor.size())
    device_str = '' if not tensor.is_cuda else \
        ' (GPU {})'.format(tensor.get_device())
    strt = '[{} of size {}{}]'.format(torch.typename(tensor),
                                      size_str, device_str)
    return strt
